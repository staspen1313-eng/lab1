<script setup>
import { ref, computed } from 'vue'
import QuoteDisplay from './components/QuoteDisplay.vue'
import QuotesList from './components/QuotesList.vue'

const quotes = ref([
  { text: 'Чим глибше в ліс, тим більше шкібіді доп ес-ес', creator: '67' },
  { text: 'Борітеся - поборете! Вам Бог помагає!', creator: 'Тарас Шевченко' },
  { text: 'Ні, я жива! Я буду вічно жити! Я в серці маю те, що не вмирає.', creator: 'Леся Українка' },
  { text: 'Лиш боротись - значит жити!', creator: 'Іван Франко' },
  { text: 'Людина без мети - як птах без крил.', creator: 'Григорій Сковорода' },
  { text: 'Україна починається з тебе.', creator: 'В’ячеслав Чорновіл' }
])

const activeQuote = ref(null)

const textInput = ref('')
const authorInput = ref('')

const wordCount = computed(() => {
  if (!activeQuote.value) return 0
  return activeQuote.value.text.split(' ').length
})

function getRandom() {
  const rand = Math.floor(Math.random() * quotes.value.length)
  activeQuote.value = quotes.value[rand]
  // console.log(activeQuote.value)
}

function add() {
  if (textInput.value == '' || authorInput.value == '') {
    alert('Заповніть поля!')
    return
  }
  
  quotes.value.push({
    text: textInput.value,
    creator: authorInput.value
  })
  
  textInput.value = ''
  authorInput.value = ''
}
</script>

<template>
  <div class="main-container">
    <h2>Генератор цитат</h2>

    <div class="inputs">
      <input v-model="textInput" placeholder="Текст цитати" />
      <input v-model="authorInput" placeholder="Автор" />
      <button @click="add">Додати</button>
    </div>

    <button class="big-btn" @click="getRandom">Згенерувати цитату</button>

    <div v-if="activeQuote == null" class="empty-state">
      Тут буде цитата...
    </div>

    <QuoteDisplay 
      v-else 
      :quote="activeQuote" 
      :wordCount="wordCount" 
    />

    <QuotesList :quotes="quotes" />
  </div>
</template>

<style scoped>
.main-container {
  max-width: 700px;
  margin: 20px auto;
  font-family: Arial, sans-serif;
}
.inputs {
  display: flex;
  margin-bottom: 20px;
}
.inputs input {
  margin-right: 5px;
  padding: 5px;
}
.big-btn {
  width: 100%;
  padding: 15px;
  background: green;
  color: white;
  border: none;
  cursor: pointer;
  margin-bottom: 20px;
}
.empty-state {
  border: 1px dashed gray;
  padding: 20px;
  text-align: center;
  margin-bottom: 20px;
}
</style>