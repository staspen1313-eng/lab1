<script setup>
const props = defineProps({
  quote: Object,
  wordCount: Number
})
</script>

<template>
  <div class="q-box">
    <p class="quote-text">"{{ quote.text }}"</p>
    <div class="bottom-info">
      <b class="author">— {{ quote.creator }}</b>
      <span class="count-badge">Слів: {{ wordCount }}</span>
    </div>
  </div>
</template>

<style scoped>
.q-box {
  padding: 20px;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-bottom: 25px;
}
.quote-text {
  font-size: 20px;
  font-style: italic;
  margin-bottom: 15px;
}
.bottom-info {
  display: flex;
  justify-content: space-between;
}
.count-badge {
  background: #eee;
  padding: 5px;
  border-radius: 5px;
  font-size: 14px;
}
</style>