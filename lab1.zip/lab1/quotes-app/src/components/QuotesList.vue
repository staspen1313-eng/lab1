<script setup>
defineProps({
  quotes: Array
})
</script>

<template>
  <div class="list-wrap">
    <h3>Усі цитати ({{ quotes.length }} шт.)</h3>
    <ul>
      <li v-for="(q, i) in quotes" :key="i">
        <span>{{ q.text }}</span>
        <span class="auth">{{ q.creator }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.list-wrap {
  margin-top: 30px;
  border-top: 2px solid black;
  padding-top: 15px;
}
ul {
  padding-left: 0;
}
li {
  list-style: none;
  padding: 10px;
  background: #f4f4f4;
  margin-bottom: 10px;
  border-radius: 5px;
}
.auth {
  display: block;
  font-size: 12px;
  color: gray;
  margin-top: 5px;
}
</style>